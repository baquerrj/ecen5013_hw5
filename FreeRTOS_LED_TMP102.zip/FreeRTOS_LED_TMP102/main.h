/*!
 * @file	main.h
 *
 * @brief
 *
 *  Created on: Apr 10, 2019
 *      Author: Roberto Baquerizo
 */

#ifndef MAIN_H_
#define MAIN_H_

#define CLOCK_FREQ      (120000000)


#endif /* MAIN_H_ */
